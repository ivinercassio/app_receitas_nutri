package com.ivinercassio.ReceitasNutriApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReceitasNutriApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
