package com.ivinercassio.ReceitasNutriApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReceitasNutriApiApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(ReceitasNutriApiApplication.class, args);
	}

}
