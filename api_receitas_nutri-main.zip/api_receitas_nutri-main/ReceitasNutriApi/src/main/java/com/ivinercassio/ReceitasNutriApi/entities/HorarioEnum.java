package com.ivinercassio.ReceitasNutriApi.entities;

public enum HorarioEnum {
    CAFE_DA_MANHA, LANCHE, ALMOCO, JANTA
}
