package com.ivinercassio.ReceitasNutriApi.entities;

public enum NivelAcesso {
    ADMIN, NUTRICIONISTA, PACIENTE
}
